using System.Windows;
namespace FitClub.App;
public partial class App : Application
{
 protected override void OnStartup(StartupEventArgs e)
 {
  base.OnStartup(e);
  var window = new MainWindow();
  var captureIndex = Array.IndexOf(e.Args, "--capture");
  if (captureIndex >= 0 && captureIndex + 1 < e.Args.Length) window.CaptureDirectory = e.Args[captureIndex + 1];
  MainWindow = window;
  window.Show();
 }
}
