using System.Data;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using FitClub.Core;
namespace FitClub.App;
public partial class MainWindow : Window
{
 private ClubService? service;
 private ClubService Service => service ??= new ClubService(AppConfiguration.LoadConnectionString());
 private int? editingMemberId;
 private bool busy, dataLoaded;
 public string? CaptureDirectory { get; set; }
 public MainWindow()
 {
  InitializeComponent();
  Language = System.Windows.Markup.XmlLanguage.GetLanguage("ru-RU");
  MembershipStart.SelectedDate=DateTime.Today; MembershipEnd.SelectedDate=DateTime.Today.AddDays(30);
  SessionDate.SelectedDate=DateTime.Today.AddDays(1);
  ScheduleFrom.SelectedDate=DateTime.Today; ScheduleTo.SelectedDate=DateTime.Today.AddDays(14);
  ReportFrom.SelectedDate=DateTime.Today; ReportTo.SelectedDate=DateTime.Today.AddDays(30);
 }
 private async void Window_Loaded(object sender,RoutedEventArgs e)
 {
  await RunAsync("Данные загружены",RefreshAllAsync);
  if(CaptureDirectory is not null)
  {
   if(!dataLoaded){Application.Current.Shutdown(2);return;}
   try {await CaptureAsync(CaptureDirectory);Application.Current.Shutdown(0);}
   catch {Application.Current.Shutdown(3);}
  }
 }
 // SQL runs on a worker thread; all bindings are updated on the UI thread.
 private async Task RunAsync(string success,Func<Task> operation)
 {
  if(busy)return;
  busy=true;MainBody.IsEnabled=false;RefreshButton.IsEnabled=false;StatusText.Text="Выполняется операция…";
  try {await operation();ConnectionStatus.Text="SQL Server · подключено";StatusText.Text=success;}
  catch(OperationCanceledException){StatusText.Text="Операция отменена пользователем";}
  catch(BusinessRuleException ex){ShowError(ex.Message);}
  catch(Exception)
  {
   ConnectionStatus.Text="Проверьте подключение";
   ShowError("Не удалось выполнить операцию. Проверьте доступность SQL Server и настройки подключения. Затем нажмите «Обновить данные». Подробности настройки приведены в README.");
  }
  finally {MainBody.IsEnabled=true;RefreshButton.IsEnabled=true;busy=false;}
 }
 private void ShowError(string message)
 {
  StatusText.Text=message;
  if(CaptureDirectory is null)MessageBox.Show(this,message,"FitClub",MessageBoxButton.OK,MessageBoxImage.Information);
 }
 private async Task RefreshAllAsync()
 {
  string memberSearch=MemberSearch.Text.Trim(),scheduleSearch=ScheduleSearch.Text.Trim();
  bool archived=IncludeArchived.IsChecked==true;
  var scheduleRange=ReadRange(ScheduleFrom,ScheduleTo);var reportRange=ReadRange(ReportFrom,ReportTo);
  var svc=Service;
  var tables=await Task.Run(()=>new Dictionary<string,DataTable>
  {
   ["members"]=svc.Members(memberSearch,archived),["activeMembers"]=svc.Members(),["plans"]=svc.Plans(),
   ["trainers"]=svc.Trainers(),["rooms"]=svc.Rooms(),["memberships"]=svc.Memberships(),
   ["sessions"]=svc.Sessions(scheduleRange.from,scheduleRange.to,scheduleSearch),["bookings"]=svc.Bookings(),
   ["report"]=svc.Report(reportRange.from,reportRange.to)
  });
  Bind(MembersGrid,MembersCount,tables["members"]);Bind(MembershipsGrid,MembershipsCount,tables["memberships"]);
  Bind(SessionsGrid,SessionsCount,tables["sessions"]);Bind(BookingsGrid,BookingsCount,tables["bookings"]);
  BindReport(tables["report"]);
  SetOptions(MembershipMember,tables["activeMembers"]);SetOptions(MembershipPlan,tables["plans"]);
  SetOptions(SessionTrainer,tables["trainers"]);SetOptions(SessionRoom,tables["rooms"]);
  var choices=tables["memberships"].Copy();var activeIds=tables["activeMembers"].AsEnumerable().Select(r=>r.Field<int>("Id")).ToHashSet(); foreach(var row in choices.AsEnumerable().Where(r=>!activeIds.Contains(r.Field<int>("MemberId"))).ToArray()) choices.Rows.Remove(row); choices.DefaultView.Sort="Id ASC";choices.Columns.Add("DisplayLabel",typeof(string));
  foreach(DataRow row in choices.Rows)row["DisplayLabel"]=$"№{row["Id"]} · {row["Client"]} · {row["Plan"]} · остаток {row["VisitsRemaining"]}";
  SetOptions(BookingMembership,choices);dataLoaded=true;
 }
 private static void SetOptions(ComboBox box,DataTable table)
 {
  object? selected=box.SelectedValue;box.ItemsSource=table.DefaultView;
  if(selected is not null)box.SelectedValue=selected;
  if(box.SelectedIndex<0&&box.Items.Count>0)box.SelectedIndex=0;
 }
 private static void Bind(DataGrid grid,TextBlock count,DataTable table)
 {
  grid.ItemsSource=table.DefaultView;
  count.Text=table.Rows.Count==0?"Ничего не найдено. Измените условия или добавьте запись.":$"Записей: {table.Rows.Count}";
 }
 private void BindReport(DataTable table)
 {
  Bind(ReportGrid,ReportCount,table);
  int active=table.AsEnumerable().Sum(r=>Convert.ToInt32(r["ActiveBookings"]));
  int cancelled=table.AsEnumerable().Sum(r=>Convert.ToInt32(r["CancelledBookings"]));
  int capacity=table.AsEnumerable().Sum(r=>Convert.ToInt32(r["Capacity"]));
  decimal fill=capacity==0?0:(decimal)active/capacity*100;
  ReportSummary.Text=$"Занятий: {table.Rows.Count}     Записей: {active}     Отмен: {cancelled}     Общая загрузка: {fill:0.#}%";
 }
 private static (DateTime from,DateTime to) ReadRange(DatePicker from,DatePicker to)
 {
  var first=from.SelectedDate??throw new BusinessRuleException("Укажите начало периода.");
  var last=to.SelectedDate??throw new BusinessRuleException("Укажите конец периода.");
  if(last<first)throw new BusinessRuleException("Конец периода не может быть раньше начала.");
  if(last>=DateTime.MaxValue.Date)throw new BusinessRuleException("Укажите допустимую дату окончания.");
  return(first.Date,last.Date);
 }
 private static int SelectedId(ComboBox box,string message)=>box.SelectedValue is int id?id:throw new BusinessRuleException(message);
 private static DataRowView SelectedRow(DataGrid grid,string message)=>grid.SelectedItem as DataRowView??throw new BusinessRuleException(message);
 private static DateTime SelectedDate(DatePicker picker,string message)=>picker.SelectedDate?.Date??throw new BusinessRuleException(message);
 private async Task MutateAsync(Action action){await Task.Run(action);await RefreshAllAsync();}
 private async void Refresh_Click(object sender,RoutedEventArgs e)
 {service=null;await RunAsync("Данные обновлены",RefreshAllAsync);}
 private async void SearchMembers_Click(object sender,RoutedEventArgs e)=>await RunAsync("Поиск выполнен",async()=>
 {
  string search=MemberSearch.Text.Trim();bool archived=IncludeArchived.IsChecked==true;var svc=Service;
  Bind(MembersGrid,MembersCount,await Task.Run(()=>svc.Members(search,archived)));
 });
 private void MemberSearch_KeyDown(object sender,KeyEventArgs e){if(e.Key==Key.Enter)SearchMembers_Click(sender,e);}
 private void Members_SelectionChanged(object sender,SelectionChangedEventArgs e)
 {
  if(MembersGrid.SelectedItem is not DataRowView row)return;
  editingMemberId=Convert.ToInt32(row["Id"]);MemberFormTitle.Text=$"Клиент №{editingMemberId}";
  MemberName.Text=Convert.ToString(row["FullName"])??"";MemberPhone.Text=Convert.ToString(row["Phone"])??"";MemberEmail.Text=Convert.ToString(row["Email"])??"";
 }
 private void NewMember_Click(object sender,RoutedEventArgs e)
 {editingMemberId=null;MembersGrid.SelectedItem=null;MemberFormTitle.Text="Новый клиент";MemberName.Clear();MemberPhone.Clear();MemberEmail.Clear();MemberName.Focus();}
 private async void SaveMember_Click(object sender,RoutedEventArgs e)=>await RunAsync("Карточка клиента сохранена",async()=>
 {
  int? id=editingMemberId;string name=MemberName.Text.Trim(),phone=MemberPhone.Text.Trim(),email=MemberEmail.Text.Trim();var svc=Service;
  await MutateAsync(()=>svc.SaveMember(id,name,phone,email));NewMember_Click(sender,e);
 });
 private async void ArchiveMember_Click(object sender,RoutedEventArgs e)=>await RunAsync("Клиент перемещён в архив",async()=>
 {
  var row=SelectedRow(MembersGrid,"Выберите клиента в таблице.");int id=Convert.ToInt32(row["Id"]);
  if(MessageBox.Show(this,$"Архивировать клиента «{row["FullName"]}»? История сохранится, новые записи будут недоступны.","Архивирование",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)throw new OperationCanceledException();
  var svc=Service;await MutateAsync(()=>svc.ArchiveMember(id));NewMember_Click(sender,e);
 });
 private async void AddMembership_Click(object sender,RoutedEventArgs e)=>await RunAsync("Абонемент выдан",async()=>
 {
  int member=SelectedId(MembershipMember,"Выберите клиента."),plan=SelectedId(MembershipPlan,"Выберите тариф.");
  var start=SelectedDate(MembershipStart,"Укажите начало действия абонемента.");var end=SelectedDate(MembershipEnd,"Укажите окончание действия абонемента.");
  var svc=Service;await MutateAsync(()=>svc.AddMembership(member,plan,start,end));
 });
 private void Memberships_SelectionChanged(object sender,SelectionChangedEventArgs e)
 {if(MembershipsGrid.SelectedItem is DataRowView row)FreezeButton.Content=Convert.ToBoolean(row["IsFrozen"])?"Разморозить выбранный":"Заморозить выбранный";}
 private async void Freeze_Click(object sender,RoutedEventArgs e)=>await RunAsync("Статус абонемента изменён",async()=>
 {
  var row=SelectedRow(MembershipsGrid,"Выберите абонемент в таблице.");int id=Convert.ToInt32(row["Id"]);bool frozen=!Convert.ToBoolean(row["IsFrozen"]);
  var svc=Service;await MutateAsync(()=>svc.SetMembershipFrozen(id,frozen));
 });
 private async void FilterSessions_Click(object sender,RoutedEventArgs e)=>await RunAsync("Расписание обновлено",async()=>
 {
  var range=ReadRange(ScheduleFrom,ScheduleTo);string search=ScheduleSearch.Text.Trim();var svc=Service;
  Bind(SessionsGrid,SessionsCount,await Task.Run(()=>svc.Sessions(range.from,range.to,search)));
 });
 private async void AddSession_Click(object sender,RoutedEventArgs e)=>await RunAsync("Занятие добавлено в расписание",async()=>
 {
  string title=SessionTitle.Text.Trim();int trainer=SelectedId(SessionTrainer,"Выберите тренера."),room=SelectedId(SessionRoom,"Выберите зал.");
  var date=SelectedDate(SessionDate,"Укажите дату занятия.");
  if(!TimeSpan.TryParseExact(SessionTime.Text.Trim(),@"hh\:mm",CultureInfo.InvariantCulture,out var time))throw new BusinessRuleException("Укажите время в формате ЧЧ:ММ, например 18:00.");
  if(!int.TryParse(SessionDuration.Text,out int duration)||!int.TryParse(SessionCapacity.Text,out int capacity))throw new BusinessRuleException("Длительность и количество мест должны быть целыми числами.");
  var svc=Service;await MutateAsync(()=>svc.AddSession(title,trainer,room,date.Add(time),duration,capacity));
 });
 private async void Book_Click(object sender,RoutedEventArgs e)=>await RunAsync("Клиент записан. Одно посещение списано",async()=>
 {
  var session=SelectedRow(SessionsGrid,"Выберите занятие в расписании.");var membership=BookingMembership.SelectedItem as DataRowView??throw new BusinessRuleException("Выберите абонемент для записи.");
  int memberId=Convert.ToInt32(membership["MemberId"]),membershipId=Convert.ToInt32(membership["Id"]),sessionId=Convert.ToInt32(session["Id"]);
  var svc=Service;await MutateAsync(()=>svc.Book(memberId,membershipId,sessionId));
 });
 private async void CancelBooking_Click(object sender,RoutedEventArgs e)=>await RunAsync("Запись отменена. Посещение возвращено",async()=>
 {
  var row=SelectedRow(BookingsGrid,"Выберите запись для отмены.");int id=Convert.ToInt32(row["Id"]);
  if(MessageBox.Show(this,$"Отменить запись клиента «{row["Client"]}» на «{row["Title"]}»?","Отмена записи",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)throw new OperationCanceledException();
  var svc=Service;await MutateAsync(()=>svc.CancelBooking(id));
 });
 private async void Report_Click(object sender,RoutedEventArgs e)=>await RunAsync("Отчёт сформирован",async()=>
 {var range=ReadRange(ReportFrom,ReportTo);var svc=Service;BindReport(await Task.Run(()=>svc.Report(range.from,range.to)));});
 private static readonly Dictionary<string,string> Headers=new()
 {
  ["Id"]="№",["FullName"]="ФИО",["Phone"]="Телефон",["Email"]="Email",["IsArchived"]="Архив",["Client"]="Клиент",["Plan"]="Тариф",["StartsOn"]="Начало",["EndsOn"]="Окончание",["VisitsRemaining"]="Остаток",["IsFrozen"]="Заморожен",["Title"]="Занятие",["Trainer"]="Тренер",["Room"]="Зал",["StartsAt"]="Начало",["DurationMinutes"]="Мин",["Capacity"]="Мест",["Booked"]="Записи",["Free"]="Своб.",["Status"]="Статус",["ActiveBookings"]="Записи",["CancelledBookings"]="Отмен",["OccupancyPercent"]="Загрузка, %",["SessionId"]="№"
 };
 private void Grid_AutoGeneratingColumn(object sender,DataGridAutoGeneratingColumnEventArgs e)
 {
  if(e.PropertyName is "MemberId" or "PlanId" or "MembershipId" or "TrainerId" or "RoomId"){e.Cancel=true;return;}
  e.Column.Header=Headers.GetValueOrDefault(e.PropertyName,e.PropertyName);
  if(e.Column is DataGridTextColumn textColumn)
  {
   var binding=new Binding(e.PropertyName);
   if(e.PropertyType==typeof(DateTime))binding.StringFormat=e.PropertyName=="StartsAt"?"dd.MM.yyyy\nHH:mm":"dd.MM.yyyy";
   if(e.PropertyName=="OccupancyPercent")binding.StringFormat="0.#";
   textColumn.Binding=binding;
   textColumn.ElementStyle=new Style(typeof(TextBlock)){Setters={new Setter(TextBlock.MarginProperty,new Thickness(7,7,7,7)),new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center),new Setter(TextBlock.TextWrappingProperty,TextWrapping.Wrap)}};
  }
  e.Column.MinWidth=35;
  e.Column.Width=e.PropertyName switch { "Id"=>35, "SessionId"=>85, "StartsAt"=>110, "StartsOn" or "EndsOn"=>100, "VisitsRemaining"=>85, "IsFrozen"=>95, "DurationMinutes"=>50, "Capacity"=>50, "Booked" or "ActiveBookings"=>70, "Free"=>75, "CancelledBookings"=>70, "OccupancyPercent"=>115, "Trainer"=>110, "Room"=>120, "Plan"=>180, "Title" when ReferenceEquals(sender,SessionsGrid)=>155, "FullName" or "Client" or "Title"=>new DataGridLength(1,DataGridLengthUnitType.Star), _=>DataGridLength.Auto };
 }
 private async Task CaptureAsync(string directory)
 {
  Directory.CreateDirectory(directory);
  string[] names=["01-clients","02-memberships","03-schedule","04-bookings","05-report"];
  for(int i=0;i<MainBody.Items.Count;i++)
  {
   MainBody.SelectedIndex=i;await Dispatcher.InvokeAsync(()=>{},DispatcherPriority.ApplicationIdle);UpdateLayout();
   var visual=(FrameworkElement)Content; var bitmap=new RenderTargetBitmap((int)Math.Ceiling(visual.ActualWidth),(int)Math.Ceiling(visual.ActualHeight),96,96,PixelFormats.Pbgra32);bitmap.Render(visual);
   var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
   using var file=File.Create(Path.Combine(directory,names[i]+".png"));encoder.Save(file);
  }
 }
}


