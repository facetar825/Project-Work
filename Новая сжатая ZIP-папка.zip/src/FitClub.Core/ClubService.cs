using System.Data;
using static FitClub.Core.SqlStore;

namespace FitClub.Core;

public sealed class ClubService(string connectionString)
{
    private readonly SqlStore db = new(connectionString);
    public DataTable Members(string search = "", bool includeArchived = false) => db.Query("SELECT Id,FullName,Phone,Email,IsArchived FROM dbo.Members WHERE (@all=1 OR IsArchived=0) AND (@q=N'' OR CHARINDEX(@q,FullName)>0 OR CHARINDEX(@q,Phone)>0 OR CHARINDEX(@q,Email)>0) ORDER BY FullName;", Text("@q", search.Trim(), 150), Bit("@all", includeArchived));
    public DataTable Plans() => db.Query("SELECT Id,Name,VisitLimit,Price FROM dbo.Plans ORDER BY Id;");
    public DataTable Trainers() => db.Query("SELECT Id,FullName FROM dbo.Trainers ORDER BY FullName;");
    public DataTable Rooms() => db.Query("SELECT Id,Name,Capacity FROM dbo.Rooms ORDER BY Name;");
    public DataTable Memberships(int? memberId = null) => db.Query("SELECT a.Id,a.MemberId,m.FullName AS Client,a.PlanId,p.Name AS [Plan],a.StartsOn,a.EndsOn,a.VisitsRemaining,a.IsFrozen FROM dbo.Memberships a JOIN dbo.Members m ON m.Id=a.MemberId JOIN dbo.Plans p ON p.Id=a.PlanId WHERE (@id=0 OR a.MemberId=@id) ORDER BY a.Id DESC;", Int("@id", memberId ?? 0));
    public DataTable Sessions(DateTime from, DateTime to, string search = "")
    {
        Validation.Range(from, to);
        return db.Query("SELECT s.Id,s.Title,t.FullName AS Trainer,r.Name AS Room,s.StartsAt,s.DurationMinutes,s.Capacity,COUNT(b.Id) AS Booked,s.Capacity-COUNT(b.Id) AS Free FROM dbo.Sessions s JOIN dbo.Trainers t ON t.Id=s.TrainerId JOIN dbo.Rooms r ON r.Id=s.RoomId LEFT JOIN dbo.Bookings b ON b.SessionId=s.Id AND b.CancelledAt IS NULL WHERE s.StartsAt>=@from AND s.StartsAt<@to AND (@q=N'' OR CHARINDEX(@q,s.Title)>0 OR CHARINDEX(@q,t.FullName)>0 OR CHARINDEX(@q,r.Name)>0) GROUP BY s.Id,s.Title,t.FullName,r.Name,s.StartsAt,s.DurationMinutes,s.Capacity ORDER BY s.StartsAt;", Date("@from", from.Date), Date("@to", to.Date.AddDays(1)), Text("@q", search.Trim(), 100));
    }
    public DataTable Bookings() => db.Query("SELECT b.Id,m.FullName AS Client,s.Title,s.StartsAt,CASE WHEN b.CancelledAt IS NULL THEN N'Активна' ELSE N'Отменена' END AS Status,b.MembershipId FROM dbo.Bookings b JOIN dbo.Members m ON m.Id=b.MemberId JOIN dbo.Sessions s ON s.Id=b.SessionId ORDER BY b.Id DESC;");
    public DataTable Report(DateTime from, DateTime to)
    {
        Validation.Range(from, to);
        return db.Query("SELECT s.Id AS SessionId,s.Title,s.StartsAt,s.Capacity,SUM(CASE WHEN b.Id IS NOT NULL AND b.CancelledAt IS NULL THEN 1 ELSE 0 END) AS ActiveBookings,SUM(CASE WHEN b.CancelledAt IS NOT NULL THEN 1 ELSE 0 END) AS CancelledBookings,CAST(100.0*SUM(CASE WHEN b.Id IS NOT NULL AND b.CancelledAt IS NULL THEN 1 ELSE 0 END)/s.Capacity AS decimal(6,1)) AS OccupancyPercent FROM dbo.Sessions s LEFT JOIN dbo.Bookings b ON b.SessionId=s.Id WHERE s.StartsAt>=@from AND s.StartsAt<@to GROUP BY s.Id,s.Title,s.StartsAt,s.Capacity ORDER BY s.StartsAt;", Date("@from", from.Date), Date("@to", to.Date.AddDays(1)));
    }
    public void SaveMember(int? id, string fullName, string phone, string email)
    {
        fullName = Validation.Required(fullName, "ФИО", 100);
        phone = Validation.Required(phone, "Телефон", 30);
        if (phone.Count(char.IsDigit) < 7 || phone.Any(c => !char.IsDigit(c) && !"+()- ".Contains(c)))
            throw new BusinessRuleException("Телефон: минимум 7 цифр; допустимы +, пробелы, скобки и дефис.");
        email = Validation.Email(email);
        db.Mutate("IF @id=0 INSERT dbo.Members(FullName,Phone,Email) VALUES(@name,@phone,@email); ELSE BEGIN UPDATE dbo.Members SET FullName=@name,Phone=@phone,Email=@email WHERE Id=@id AND IsArchived=0; IF @@ROWCOUNT=0 THROW 50001,N'Клиент не найден или находится в архиве.',1; END;", Int("@id", id ?? 0), Text("@name", fullName, 100), Text("@phone", phone, 30), Text("@email", email, 150));
    }
    public void ArchiveMember(int id) => db.Mutate("IF EXISTS(SELECT 1 FROM dbo.Bookings b JOIN dbo.Sessions s ON s.Id=b.SessionId WHERE b.MemberId=@id AND b.CancelledAt IS NULL AND s.StartsAt>SYSDATETIME()) THROW 50001,N'Сначала отмените будущие записи клиента.',1; UPDATE dbo.Members SET IsArchived=1 WHERE Id=@id AND IsArchived=0; IF @@ROWCOUNT=0 THROW 50001,N'Клиент не найден или уже в архиве.',1;", Int("@id", id));
    public void AddMembership(int memberId, int planId, DateTime startsOn, DateTime endsOn)
    {
        Validation.Range(startsOn, endsOn);
        db.Mutate("IF NOT EXISTS(SELECT 1 FROM dbo.Members WHERE Id=@m AND IsArchived=0) THROW 50001,N'Выберите действующего клиента.',1; IF NOT EXISTS(SELECT 1 FROM dbo.Plans WHERE Id=@p) THROW 50001,N'Тариф не найден.',1; INSERT dbo.Memberships(MemberId,PlanId,StartsOn,EndsOn,VisitsRemaining) SELECT @m,Id,@start,@end,VisitLimit FROM dbo.Plans WHERE Id=@p;", Int("@m", memberId), Int("@p", planId), Date("@start", startsOn.Date), Date("@end", endsOn.Date));
    }
    public void SetMembershipFrozen(int id, bool frozen) => db.Mutate("UPDATE dbo.Memberships SET IsFrozen=@f WHERE Id=@id; IF @@ROWCOUNT=0 THROW 50001,N'Абонемент не найден.',1;", Int("@id", id), Bit("@f", frozen));
    public void AddSession(string title, int trainerId, int roomId, DateTime startsAt, int durationMinutes, int capacity)
    {
        title = Validation.Required(title, "Название занятия", 100);
        if (durationMinutes < 15 || durationMinutes > 240 || capacity < 1 || capacity > 1000)
            throw new BusinessRuleException("Длительность — от 15 до 240 минут, вместимость — от 1 до 1000.");
        db.Mutate("IF @start<=SYSDATETIME() THROW 50001,N'Занятие должно начинаться в будущем.',1; IF NOT EXISTS(SELECT 1 FROM dbo.Trainers WHERE Id=@t) THROW 50001,N'Тренер не найден.',1; IF NOT EXISTS(SELECT 1 FROM dbo.Rooms WHERE Id=@r AND Capacity>=@cap) THROW 50001,N'Вместимость занятия превышает вместимость зала.',1; IF EXISTS(SELECT 1 FROM dbo.Sessions WHERE (TrainerId=@t OR RoomId=@r) AND StartsAt<DATEADD(minute,@duration,@start) AND DATEADD(minute,DurationMinutes,StartsAt)>@start) THROW 50001,N'Зал или тренер занят в выбранное время.',1; INSERT dbo.Sessions(Title,TrainerId,RoomId,StartsAt,DurationMinutes,Capacity) VALUES(@title,@t,@r,@start,@duration,@cap);", Text("@title", title, 100), Int("@t", trainerId), Int("@r", roomId), Date("@start", startsAt), Int("@duration", durationMinutes), Int("@cap", capacity));
    }
    public void Book(int memberId, int membershipId, int sessionId) => db.Mutate("""
        DECLARE @start datetime2,@duration int,@capacity int;
        IF NOT EXISTS(SELECT 1 FROM dbo.Members WITH(UPDLOCK,HOLDLOCK) WHERE Id=@m AND IsArchived=0)
            THROW 50001,N'Клиент не найден или находится в архиве.',1;
        SELECT @start=StartsAt,@duration=DurationMinutes,@capacity=Capacity FROM dbo.Sessions WITH(UPDLOCK,HOLDLOCK) WHERE Id=@s;
        IF @start IS NULL THROW 50001,N'Занятие не найдено.',1;
        IF @start<=SYSDATETIME() THROW 50001,N'Запись на начавшееся занятие запрещена.',1;
        IF NOT EXISTS(SELECT 1 FROM dbo.Memberships WITH(UPDLOCK,HOLDLOCK) WHERE Id=@a AND MemberId=@m AND IsFrozen=0 AND VisitsRemaining>0 AND StartsOn<=CAST(@start AS date) AND EndsOn>=CAST(@start AS date))
            THROW 50001,N'Абонемент недействителен на дату занятия, заморожен или посещения закончились.',1;
        IF EXISTS(SELECT 1 FROM dbo.Bookings WHERE MemberId=@m AND SessionId=@s AND CancelledAt IS NULL)
            THROW 50001,N'Клиент уже записан на это занятие.',1;
        IF EXISTS(SELECT 1 FROM dbo.Bookings b JOIN dbo.Sessions s ON s.Id=b.SessionId WHERE b.MemberId=@m AND b.CancelledAt IS NULL AND s.StartsAt<DATEADD(minute,@duration,@start) AND DATEADD(minute,s.DurationMinutes,s.StartsAt)>@start)
            THROW 50001,N'У клиента уже есть запись на пересекающееся по времени занятие.',1;
        IF (SELECT COUNT(*) FROM dbo.Bookings WHERE SessionId=@s AND CancelledAt IS NULL)>=@capacity
            THROW 50001,N'На занятии нет свободных мест.',1;
        UPDATE dbo.Memberships SET VisitsRemaining=VisitsRemaining-1 WHERE Id=@a;
        INSERT dbo.Bookings(MemberId,MembershipId,SessionId) VALUES(@m,@a,@s);
        """, Int("@m", memberId), Int("@a", membershipId), Int("@s", sessionId));
    public void CancelBooking(int bookingId) => db.Mutate("""
        DECLARE @a int,@start datetime2,@cancelled datetime2;
        SELECT @a=b.MembershipId,@start=s.StartsAt,@cancelled=b.CancelledAt FROM dbo.Bookings b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.Sessions s ON s.Id=b.SessionId WHERE b.Id=@id;
        IF @a IS NULL THROW 50001,N'Запись не найдена.',1;
        IF @cancelled IS NOT NULL THROW 50001,N'Запись уже отменена.',1;
        IF @start<=SYSDATETIME() THROW 50001,N'После начала занятия отмена с возвратом посещения запрещена.',1;
        UPDATE dbo.Bookings SET CancelledAt=SYSDATETIME() WHERE Id=@id;
        UPDATE dbo.Memberships SET VisitsRemaining=VisitsRemaining+1 WHERE Id=@a;
        """, Int("@id", bookingId));
}

