using System.Text.Json;
using System.Net.Mail;

namespace FitClub.Core;

public sealed class BusinessRuleException(string message) : Exception(message);

public static class AppConfiguration
{
    public static string LoadConnectionString()
    {
        var value = Environment.GetEnvironmentVariable("FITCLUB_CONNECTION_STRING");
        if (!string.IsNullOrWhiteSpace(value)) return value;
        var path = Path.Combine(AppContext.BaseDirectory, "connection.local.json");
        if (File.Exists(path))
        {
            using var json = JsonDocument.Parse(File.ReadAllText(path));
            if (json.RootElement.TryGetProperty("ConnectionString", out var property) && !string.IsNullOrWhiteSpace(property.GetString()))
                return property.GetString()!;
            throw new BusinessRuleException("Укажите ConnectionString в connection.local.json.");
        }
        return "Server=localhost;Database=FitClub_Study;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;Connect Timeout=5";
    }
}

internal static class Validation
{
    public static string Required(string? value, string field, int max)
    {
        value = value?.Trim() ?? "";
        if (value.Length == 0 || value.Length > max)
            throw new BusinessRuleException($"{field}: введите от 1 до {max} символов.");
        return value;
    }
    public static string Email(string? value)
    {
        value = value?.Trim() ?? "";
        if (value.Length > 150 || (value.Length > 0 && (!MailAddress.TryCreate(value, out var address) || address.Address != value)))
            throw new BusinessRuleException("Введите корректный email или оставьте поле пустым.");
        return value;
    }
    public static void Range(DateTime from, DateTime to)
    {
        if (to.Date < from.Date || to.Date >= DateTime.MaxValue.Date)
            throw new BusinessRuleException("Конечная дата должна быть не раньше начальной.");
    }
}
