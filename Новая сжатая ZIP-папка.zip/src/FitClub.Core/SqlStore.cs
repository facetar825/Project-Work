using System.Data;
using Microsoft.Data.SqlClient;

namespace FitClub.Core;

// Each call owns its connection; UI and concurrent checks can safely share a service.
internal sealed class SqlStore(string connectionString)
{
    public DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using var connection = new SqlConnection(connectionString);
        connection.Open();
        return Query(connection, null, sql, parameters);
    }
    internal static DataTable Query(SqlConnection connection, SqlTransaction? transaction, string sql, params SqlParameter[] parameters)
    {
        using var command = new SqlCommand(sql, connection, transaction) { CommandTimeout = 20 };
        command.Parameters.AddRange(parameters);
        using var reader = command.ExecuteReader();
        var result = new DataTable();
        result.Load(reader);
        return result;
    }
    public void Mutate(string sql, params SqlParameter[] parameters)
    {
        using var connection = new SqlConnection(connectionString);
        connection.Open();
        using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);
        try
        {
            // A small single-club system trades write parallelism for a simple lock order.
            using (var guard = new SqlCommand("DECLARE @r int; EXEC @r = sys.sp_getapplock @Resource=N'FitClub.Mutation', @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=10000; IF @r < 0 THROW 50001, N'Система занята. Повторите операцию.', 1;", connection, transaction))
                guard.ExecuteNonQuery();
            using var command = new SqlCommand(sql, connection, transaction) { CommandTimeout = 20 };
            command.Parameters.AddRange(parameters);
            command.ExecuteNonQuery();
            transaction.Commit();
        }
        catch (SqlException ex) when (ex.Number >= 50000)
        {
            Rollback(transaction);
            throw new BusinessRuleException(ex.Message);
        }
        catch
        {
            Rollback(transaction);
            throw;
        }
    }
    private static void Rollback(SqlTransaction transaction)
    {
        try { transaction.Rollback(); } catch (InvalidOperationException) { } catch (SqlException) { }
    }
    internal static SqlParameter Int(string name, int value) => new(name, SqlDbType.Int) { Value = value };
    internal static SqlParameter Text(string name, string value, int size) => new(name, SqlDbType.NVarChar, size) { Value = value };
    internal static SqlParameter Date(string name, DateTime value) => new(name, SqlDbType.DateTime2) { Value = value };
    internal static SqlParameter Bit(string name, bool value) => new(name, SqlDbType.Bit) { Value = value };
}
