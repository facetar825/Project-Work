﻿USE [FitClub_Study];
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
BEGIN TRANSACTION;
IF EXISTS(SELECT 1 FROM dbo.Members) OR EXISTS(SELECT 1 FROM dbo.Plans) OR EXISTS(SELECT 1 FROM dbo.Memberships) OR EXISTS(SELECT 1 FROM dbo.Trainers) OR EXISTS(SELECT 1 FROM dbo.Rooms) OR EXISTS(SELECT 1 FROM dbo.Sessions) OR EXISTS(SELECT 1 FROM dbo.Bookings)
THROW 51001,N'Тестовые данные можно добавить только в пустую схему. Данные не изменены.',1;
DECLARE @today date=CONVERT(date,GETDATE());
DECLARE @tomorrow datetime2(0)=DATEADD(day,1,CONVERT(datetime2(0),@today));
DECLARE @day2 datetime2(0)=DATEADD(day,2,CONVERT(datetime2(0),@today));
SET IDENTITY_INSERT dbo.Members ON;
INSERT dbo.Members(Id,FullName,Phone,Email,IsArchived) VALUES
(1,N'Анна Соколова',N'+7 900 000-00-01',N'anna@example.test',0),
(2,N'Дмитрий Орлов',N'+7 900 000-00-02',N'dmitry@example.test',0),
(3,N'Елена Волкова',N'+7 900 000-00-03',N'elena@example.test',0),
(4,N'Игорь Петров',N'+7 900 000-00-04',N'igor@example.test',0),
(5,N'Мария Кузнецова',N'+7 900 000-00-05',N'maria@example.test',0),
(6,N'Павел Смирнов',N'+7 900 000-00-06',N'pavel@example.test',1);
SET IDENTITY_INSERT dbo.Members OFF;
SET IDENTITY_INSERT dbo.Plans ON;
INSERT dbo.Plans(Id,Name,VisitLimit,Price) VALUES
(1,N'Старт — 8 посещений',8,2400.00),(2,N'Стандарт — 12 посещений',12,3300.00),(3,N'Интенсив — 20 посещений',20,5000.00);
SET IDENTITY_INSERT dbo.Plans OFF;
SET IDENTITY_INSERT dbo.Memberships ON;
INSERT dbo.Memberships(Id,MemberId,PlanId,StartsOn,EndsOn,VisitsRemaining,IsFrozen) VALUES
(1,1,1,DATEADD(day,-7,@today),DATEADD(day,30,@today),8,0),
(2,2,2,DATEADD(day,-7,@today),DATEADD(day,30,@today),11,0),
(3,3,1,DATEADD(day,-40,@today),DATEADD(day,-1,@today),5,0),
(4,4,1,DATEADD(day,-7,@today),DATEADD(day,30,@today),0,0),
(5,5,2,DATEADD(day,-7,@today),DATEADD(day,30,@today),12,1),
(6,6,1,DATEADD(day,-7,@today),DATEADD(day,30,@today),8,0);
SET IDENTITY_INSERT dbo.Memberships OFF;
SET IDENTITY_INSERT dbo.Trainers ON;
INSERT dbo.Trainers(Id,FullName) VALUES(1,N'Алексей Морозов'),(2,N'Ольга Лебедева'),(3,N'Наталья Белова');
SET IDENTITY_INSERT dbo.Trainers OFF;
SET IDENTITY_INSERT dbo.Rooms ON;
INSERT dbo.Rooms(Id,Name,Capacity) VALUES(1,N'Большой зал',20),(2,N'Студия групповых программ',12),(3,N'Малый зал',6);
SET IDENTITY_INSERT dbo.Rooms OFF;
SET IDENTITY_INSERT dbo.Sessions ON;
INSERT dbo.Sessions(Id,Title,TrainerId,RoomId,StartsAt,DurationMinutes,Capacity) VALUES
(1,N'Функциональная тренировка',1,1,DATEADD(hour,18,@tomorrow),60,12),
(2,N'Йога для начинающих',2,2,DATEADD(minute,1155,@tomorrow),60,10),
(3,N'Пилатес',3,2,DATEADD(hour,18,@day2),60,10),
(4,N'Растяжка',3,2,DATEADD(minute,1110,@tomorrow),45,8),
(5,N'Персональная тренировка',1,3,DATEADD(hour,12,@day2),60,1),
(6,N'Прошедшая тренировка',1,1,DATEADD(hour,18,DATEADD(day,-1,CONVERT(datetime2(0),@today))),60,12);
SET IDENTITY_INSERT dbo.Sessions OFF;
SET IDENTITY_INSERT dbo.Bookings ON;
INSERT dbo.Bookings(Id,MemberId,MembershipId,SessionId,BookedAt,CancelledAt) VALUES(1,2,2,5,SYSDATETIME(),NULL);
SET IDENTITY_INSERT dbo.Bookings OFF;
COMMIT TRANSACTION;
PRINT N'Добавлены учебные данные FitClub.';
END TRY
BEGIN CATCH
IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
THROW;
END CATCH;
GO


