﻿USE [master];
GO
IF DB_ID(N'FitClub_Study') IS NULL EXEC(N'CREATE DATABASE [FitClub_Study]');
GO
USE [FitClub_Study];
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF EXISTS (SELECT 1 FROM sys.tables WHERE is_ms_shipped=0) THROW 51000,N'FitClub_Study уже содержит таблицы. Схема не изменена.',1;
BEGIN TRY
BEGIN TRANSACTION;
CREATE TABLE dbo.Members (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Members PRIMARY KEY,
FullName nvarchar(100) NOT NULL, Phone nvarchar(30) NOT NULL,
Email nvarchar(150) NOT NULL CONSTRAINT DF_Members_Email DEFAULT N'',
IsArchived bit NOT NULL CONSTRAINT DF_Members_IsArchived DEFAULT 0,
CONSTRAINT CK_Members_FullName CHECK(LEN(LTRIM(RTRIM(FullName)))>0),
CONSTRAINT CK_Members_Phone CHECK(LEN(LTRIM(RTRIM(Phone)))>0));
CREATE TABLE dbo.Plans (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Plans PRIMARY KEY,
Name nvarchar(80) NOT NULL,VisitLimit int NOT NULL,Price decimal(10,2) NOT NULL,
CONSTRAINT UQ_Plans_Name UNIQUE(Name),
CONSTRAINT CK_Plans_Name CHECK(LEN(LTRIM(RTRIM(Name)))>0),
CONSTRAINT CK_Plans_VisitLimit CHECK(VisitLimit>0),CONSTRAINT CK_Plans_Price CHECK(Price>=0));
CREATE TABLE dbo.Memberships (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Memberships PRIMARY KEY,
MemberId int NOT NULL,PlanId int NOT NULL,StartsOn date NOT NULL,EndsOn date NOT NULL,VisitsRemaining int NOT NULL,
IsFrozen bit NOT NULL CONSTRAINT DF_Memberships_IsFrozen DEFAULT 0,
CONSTRAINT FK_Memberships_Members FOREIGN KEY(MemberId) REFERENCES dbo.Members(Id),
CONSTRAINT FK_Memberships_Plans FOREIGN KEY(PlanId) REFERENCES dbo.Plans(Id),
CONSTRAINT UQ_Memberships_Id_MemberId UNIQUE(Id,MemberId),
CONSTRAINT CK_Memberships_Period CHECK(EndsOn>=StartsOn),
CONSTRAINT CK_Memberships_Remaining CHECK(VisitsRemaining>=0));
CREATE TABLE dbo.Trainers (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Trainers PRIMARY KEY,
FullName nvarchar(100) NOT NULL,
CONSTRAINT CK_Trainers_FullName CHECK(LEN(LTRIM(RTRIM(FullName)))>0));
CREATE TABLE dbo.Rooms (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Rooms PRIMARY KEY,
Name nvarchar(80) NOT NULL,Capacity int NOT NULL,
CONSTRAINT UQ_Rooms_Name UNIQUE(Name),
CONSTRAINT CK_Rooms_Name CHECK(LEN(LTRIM(RTRIM(Name)))>0),
CONSTRAINT CK_Rooms_Capacity CHECK(Capacity>0));
CREATE TABLE dbo.Sessions (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Sessions PRIMARY KEY,
Title nvarchar(100) NOT NULL,TrainerId int NOT NULL,RoomId int NOT NULL,
StartsAt datetime2(0) NOT NULL,DurationMinutes int NOT NULL,Capacity int NOT NULL,
CONSTRAINT FK_Sessions_Trainers FOREIGN KEY(TrainerId) REFERENCES dbo.Trainers(Id),
CONSTRAINT FK_Sessions_Rooms FOREIGN KEY(RoomId) REFERENCES dbo.Rooms(Id),
CONSTRAINT CK_Sessions_Title CHECK(LEN(LTRIM(RTRIM(Title)))>0),
CONSTRAINT CK_Sessions_Duration CHECK(DurationMinutes BETWEEN 15 AND 240),
CONSTRAINT CK_Sessions_Capacity CHECK(Capacity>0));
CREATE TABLE dbo.Bookings (
Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Bookings PRIMARY KEY,
MemberId int NOT NULL,MembershipId int NOT NULL,SessionId int NOT NULL,
BookedAt datetime2(0) NOT NULL CONSTRAINT DF_Bookings_BookedAt DEFAULT SYSDATETIME(),
CancelledAt datetime2(0) NULL,
CONSTRAINT FK_Bookings_Members FOREIGN KEY(MemberId) REFERENCES dbo.Members(Id),
CONSTRAINT FK_Bookings_MembershipOwner FOREIGN KEY(MembershipId,MemberId) REFERENCES dbo.Memberships(Id,MemberId),
CONSTRAINT FK_Bookings_Sessions FOREIGN KEY(SessionId) REFERENCES dbo.Sessions(Id),
CONSTRAINT CK_Bookings_CancelledAt CHECK(CancelledAt IS NULL OR CancelledAt>=BookedAt));
CREATE INDEX IX_Members_FullName ON dbo.Members(FullName);
CREATE INDEX IX_Memberships_MemberId ON dbo.Memberships(MemberId);
CREATE INDEX IX_Memberships_PlanId ON dbo.Memberships(PlanId);
CREATE INDEX IX_Sessions_StartsAt ON dbo.Sessions(StartsAt);
CREATE INDEX IX_Sessions_TrainerId_StartsAt ON dbo.Sessions(TrainerId,StartsAt);
CREATE INDEX IX_Sessions_RoomId_StartsAt ON dbo.Sessions(RoomId,StartsAt);
CREATE UNIQUE INDEX UX_Bookings_ActiveMemberSession ON dbo.Bookings(MemberId,SessionId) WHERE CancelledAt IS NULL;
CREATE INDEX IX_Bookings_SessionId ON dbo.Bookings(SessionId) INCLUDE(CancelledAt,MemberId);
CREATE INDEX IX_Bookings_MembershipOwner ON dbo.Bookings(MembershipId,MemberId);
COMMIT TRANSACTION;
PRINT N'Создана схема FitClub_Study: 7 таблиц.';
END TRY
BEGIN CATCH
IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
THROW;
END CATCH;
GO


