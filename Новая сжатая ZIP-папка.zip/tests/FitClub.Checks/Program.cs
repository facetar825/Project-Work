using FitClub.Core;
using Microsoft.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;

Console.OutputEncoding = Encoding.UTF8;
var root = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
var database = "FitClub_Checks_" + Guid.NewGuid().ToString("N");
var builder = new SqlConnectionStringBuilder(AppConfiguration.LoadConnectionString()) { InitialCatalog = "master" };
var masterConnection = builder.ConnectionString;
var results = new List<(string Id, string Name, bool Pass, string Detail)>();
var created = false;
try
{
    using (var connection = new SqlConnection(masterConnection))
    {
        connection.Open();
        foreach (var script in new[] { "schema.sql", "seed.sql" })
        {
            var sql = File.ReadAllText(Path.Combine(root, "database", script)).Replace("FitClub_Study", database, StringComparison.Ordinal);
            foreach (var batch in Regex.Split(sql, @"^\s*GO\s*\r?$", RegexOptions.Multiline | RegexOptions.IgnoreCase))
                if (!string.IsNullOrWhiteSpace(batch)) { using var command = new SqlCommand(batch, connection); command.ExecuteNonQuery(); created = true; }
        }
    }
    builder.InitialCatalog = database;
    var cs = builder.ConnectionString;
    var service = new ClubService(cs);
    void Sql(string sql) { using var c = new SqlConnection(cs); c.Open(); using var q = new SqlCommand(sql, c); q.ExecuteNonQuery(); }
    int Scalar(string sql) { using var c = new SqlConnection(cs); c.Open(); using var q = new SqlCommand(sql,c); return Convert.ToInt32(q.ExecuteScalar()); }
    void Require(bool condition, string detail) { if (!condition) throw new Exception(detail); }
    void Reject(Action action, string fragment = "")
    {
        try { action(); } catch (BusinessRuleException ex) { if (fragment.Length > 0 && !ex.Message.Contains(fragment)) throw new Exception("Unexpected business rule: " + ex.Message); return; }
        throw new Exception("Expected rejection, but operation succeeded");
    }
    async Task Check(string id, string name, Func<Task> test)
    {
        try { await test(); results.Add((id,name,true,"Все проверки сценария выполнены")); Console.WriteLine($"PASS {id} {name}"); }
        catch (Exception ex) { results.Add((id,name,false,ex.GetType().Name + ": " + ex.Message)); Console.WriteLine($"FAIL {id}: {ex.Message}"); }
    }
    Task Sync(Action action) { action(); return Task.CompletedTask; }
    await Check("T01", "CRUD, архив и параметризованный поиск", () => Sync(() =>
    {
        service.SaveMember(null,"Тестовый клиент", "+7 900 123-45-67", "test@example.org");
        int id = Convert.ToInt32(service.Members("Тестовый клиент").Rows[0]["Id"]);
        service.SaveMember(id,"Изменённый клиент", "+7 900 123-45-68", "");
        Require(service.Members("Изменённый клиент").Rows.Count == 1,"Update failed");
        Require(service.Members("' OR 1=1 --").Rows.Count == 0,"Unsafe search");
        service.ArchiveMember(id);
        Require(service.Members("Изменённый клиент").Rows.Count == 0,"Archive filter failed");
        Require(service.Members("Изменённый клиент",true).Rows.Count == 1,"Archive lost history");
    }));
    await Check("T02", "Проверка ввода и планирование", () => Sync(() =>
    {
        Reject(() => service.SaveMember(null,"", "123", "bad"));
        Reject(() => service.SaveMember(null,"Имя", "не телефон", ""));
        Reject(() => service.SaveMember(null,"Имя", "+79001234567", "bad"));
        Reject(() => service.AddMembership(1,1,DateTime.Today.AddDays(5),DateTime.Today));
        Reject(() => service.AddSession("Прошедшее",1,1,DateTime.Today.AddDays(-1),60,5));
        var row = service.Sessions(DateTime.Today,DateTime.Today.AddDays(10)).Rows.Cast<DataRow>().First(r => Convert.ToInt32(r["Id"])==1);
        Reject(() => service.AddSession("Конфликт зала",1,1,(DateTime)row["StartsAt"],60,5));
    }));
    await Check("T03", "Запись, повторная запись и пересечение", () => Sync(() =>
    {
        var before = Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1");
        service.Book(1,1,1);
        Require(Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1")==before-1,"Visit was not consumed once");
        Reject(() => service.Book(1,1,1),"уже записан");
        Reject(() => service.Book(1,1,4),"пересекающееся");
        Require(Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1")==before-1,"Rejected booking consumed visit");
    }));
    await Check("T04", "Истёкший, пустой, замороженный и чужой абонемент", () => Sync(() =>
    {
        var before=Scalar("SELECT COUNT(*) FROM dbo.Bookings");
        foreach(var id in new[]{3,4,5,6}) Reject(() => service.Book(id,id,2));
        Reject(() => service.Book(1,2,2));
        Reject(() => service.Book(1,1,6),"начавшееся");
        Reject(() => service.Book(1,1,999999),"не найдено");
        Require(Scalar("SELECT COUNT(*) FROM dbo.Bookings")==before,"Rejected action persisted");
    }));
    await Check("T05", "Последнее место при двух одновременных запросах", async () =>
    {
        Reject(() => service.Book(1,1,5),"свободных");
        Sql("INSERT dbo.Sessions(Title,TrainerId,RoomId,StartsAt,DurationMinutes,Capacity) VALUES(N'Тест конкуренции',1,1,DATEADD(day,3,CAST(CAST(GETDATE() AS date) AS datetime2)),60,1);");
        var id = Scalar("SELECT MAX(Id) FROM dbo.Sessions");
        var before=Scalar("SELECT SUM(VisitsRemaining) FROM dbo.Memberships WHERE Id IN(1,2)");
        using var start = new ManualResetEventSlim(false);
        var attempts = new[]{1,2}.Select(m => Task.Run(() => { start.Wait(); try { service.Book(m,m,id); return true; } catch(BusinessRuleException) { return false; } })).ToArray();
        start.Set();
        var outcomes=await Task.WhenAll(attempts);
        Require(outcomes.Count(x=>x)==1,"Exactly one concurrent booking must succeed");
        Require(Scalar($"SELECT COUNT(*) FROM dbo.Bookings WHERE SessionId={id} AND CancelledAt IS NULL")==1,"Overbooked");
        Require(Scalar("SELECT SUM(VisitsRemaining) FROM dbo.Memberships WHERE Id IN(1,2)")==before-1,"Wrong visit sum");
    });
    await Check("T06", "Одновременная отмена возвращает ровно одно посещение", async () =>
    {
        var id=Scalar("SELECT Id FROM dbo.Bookings WHERE MemberId=1 AND SessionId=1 AND CancelledAt IS NULL");
        var before=Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1");
        var tasks=Enumerable.Range(0,2).Select(_=>Task.Run(()=>{try{service.CancelBooking(id);return true;}catch(BusinessRuleException){return false;}})).ToArray();
        var outcomes=await Task.WhenAll(tasks);
        Require(outcomes.Count(x=>x)==1,"Cancellation must succeed once");
        Require(Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1")==before+1,"Refund duplicated or missing");
    });
    await Check("T07", "Откат после ошибки INSERT", () => Sync(() =>
    {
        Sql("CREATE TRIGGER dbo.TestRollback ON dbo.Bookings AFTER INSERT AS BEGIN THROW 51000,N'Тестовая ошибка после списания посещения',1; END;");
        var before=Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1");
        var bookings=Scalar("SELECT COUNT(*) FROM dbo.Bookings");
        try
        {
            Reject(() => service.Book(1,1,2),"Тестовая ошибка");
            Require(Scalar("SELECT VisitsRemaining FROM dbo.Memberships WHERE Id=1")==before,"Rollback did not restore visits");
            Require(Scalar("SELECT COUNT(*) FROM dbo.Bookings")==bookings,"Rollback did not restore bookings");
        }
        finally { Sql("DROP TRIGGER dbo.TestRollback;"); }
    }));
    await Check("T08", "JOIN, отчёт и защита архивирования", () => Sync(() =>
    {
        Require(service.Memberships().Rows.Count>=6,"Membership JOIN missing rows");
        var from=DateTime.Today.AddDays(-2); var to=DateTime.Today.AddDays(10);
        var report=service.Report(from,to);
        Require(report.Rows.Count>=6,"Report misses sessions");
        foreach(DataRow row in report.Rows)
        {
            int session=Convert.ToInt32(row["SessionId"]);
            Require(Convert.ToInt32(row["ActiveBookings"])==Scalar($"SELECT COUNT(*) FROM dbo.Bookings WHERE SessionId={session} AND CancelledAt IS NULL"),"Aggregate mismatch");
        }
        Require(service.Sessions(from,to,"Нет такого занятия").Rows.Count==0,"Empty search failed");
        Reject(() => service.ArchiveMember(2),"отмените");
    }));
}
catch(Exception ex) { Console.Error.WriteLine(ex); results.Add(("SETUP","Развёртывание тестовой БД",false,ex.GetType().Name)); }
finally
{
    SqlConnection.ClearAllPools();
    if(created)
    {
        using var c = new SqlConnection(masterConnection); c.Open();
        // database is generated above, never supplied by the user, and cannot name a real project DB.
        using var drop = new SqlCommand($"IF DB_ID(N'{database}') IS NOT NULL BEGIN ALTER DATABASE [{database}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{database}]; END",c);
        drop.ExecuteNonQuery();
    }
}
var reportText = new StringBuilder("# Фактические результаты автоматической проверки\n\n");
reportText.AppendLine($"Дата выполнения: {DateTimeOffset.Now:yyyy-MM-dd HH:mm zzz}. Проверки выполнялись на отдельной временной базе SQL Server, удалённой после завершения.\n");
reportText.AppendLine("| ID | Сценарий | Результат | Наблюдение |\n|---|---|---|---|");
foreach(var r in results) reportText.AppendLine($"| {r.Id} | {r.Name} | {(r.Pass ? "PASS" : "FAIL")} | {r.Detail.Replace("|","/").Replace("\n"," ")} |");
File.WriteAllText(Path.Combine(root,"docs","testing-results.md"),reportText.ToString(),new UTF8Encoding(false));
Console.WriteLine($"{results.Count(x=>x.Pass)}/{results.Count} passed");
return results.Count==8 && results.All(x=>x.Pass) ? 0 : 1;
