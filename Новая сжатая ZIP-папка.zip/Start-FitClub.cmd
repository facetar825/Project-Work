@echo off
cd /d "%~dp0"
if exist "app\FitClub.exe" (
 start "" "app\FitClub.exe"
 exit /b
)
if exist "artifacts\app\FitClub.exe" (
 start "" "artifacts\app\FitClub.exe"
 exit /b
)
dotnet run --project src\FitClub.App\FitClub.App.csproj -c Release
if errorlevel 1 pause
