﻿SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON; SET ANSI_PADDING ON; SET ANSI_WARNINGS ON; SET ARITHABORT ON; SET CONCAT_NULL_YIELDS_NULL ON; SET NUMERIC_ROUNDABORT OFF; SET XACT_ABORT ON; BEGIN TRANSACTION; IF (SELECT COUNT(*) FROM dbo.Members)<>6 OR (SELECT COUNT(*) FROM dbo.Bookings)<>1 THROW 51000, 'Unexpected data; repair stopped',1; DECLARE @today date=CONVERT(date,GETDATE()); DECLARE @tomorrow datetime2(0)=DATEADD(day,1,CONVERT(datetime2(0),@today)); DECLARE @day2 datetime2(0)=DATEADD(day,2,CONVERT(datetime2(0),@today));
UPDATE t SET t.FullName=s.FullName,t.Phone=s.Phone,t.Email=s.Email,t.IsArchived=s.IsArchived FROM dbo.Members t JOIN (VALUES (1,N'Анна Соколова',N'+7 900 000-00-01',N'anna@example.test',0),
(2,N'Дмитрий Орлов',N'+7 900 000-00-02',N'dmitry@example.test',0),
(3,N'Елена Волкова',N'+7 900 000-00-03',N'elena@example.test',0),
(4,N'Игорь Петров',N'+7 900 000-00-04',N'igor@example.test',0),
(5,N'Мария Кузнецова',N'+7 900 000-00-05',N'maria@example.test',0),
(6,N'Павел Смирнов',N'+7 900 000-00-06',N'pavel@example.test',1)) s(Id,FullName,Phone,Email,IsArchived) ON t.Id=s.Id;
UPDATE t SET t.Name=s.Name,t.VisitLimit=s.VisitLimit,t.Price=s.Price FROM dbo.Plans t JOIN (VALUES (1,N'Старт — 8 посещений',8,2400.00),(2,N'Стандарт — 12 посещений',12,3300.00),(3,N'Интенсив — 20 посещений',20,5000.00)) s(Id,Name,VisitLimit,Price) ON t.Id=s.Id;
UPDATE t SET t.FullName=s.FullName FROM dbo.Trainers t JOIN (VALUES (1,N'Алексей Морозов'),(2,N'Ольга Лебедева'),(3,N'Наталья Белова')) s(Id,FullName) ON t.Id=s.Id;
UPDATE t SET t.Name=s.Name,t.Capacity=s.Capacity FROM dbo.Rooms t JOIN (VALUES (1,N'Большой зал',20),(2,N'Студия групповых программ',12),(3,N'Малый зал',6)) s(Id,Name,Capacity) ON t.Id=s.Id;
UPDATE t SET t.Title=s.Title,t.TrainerId=s.TrainerId,t.RoomId=s.RoomId,t.StartsAt=s.StartsAt,t.DurationMinutes=s.DurationMinutes,t.Capacity=s.Capacity FROM dbo.Sessions t JOIN (VALUES (1,N'Функциональная тренировка',1,1,DATEADD(hour,18,@tomorrow),60,12),
(2,N'Йога для начинающих',2,2,DATEADD(minute,1155,@tomorrow),60,10),
(3,N'Пилатес',3,2,DATEADD(hour,18,@day2),60,10),
(4,N'Растяжка',3,2,DATEADD(minute,1110,@tomorrow),45,8),
(5,N'Персональная тренировка',1,3,DATEADD(hour,12,@day2),60,1),
(6,N'Прошедшая тренировка',1,1,DATEADD(hour,18,DATEADD(day,-1,CONVERT(datetime2(0),@today))),60,12)) s(Id,Title,TrainerId,RoomId,StartsAt,DurationMinutes,Capacity) ON t.Id=s.Id;
COMMIT;
